
# Molded Fortitude — 6‑Month Campaign Automation

Generate and schedule 24 weeks of short‑form content across TikTok, Instagram, Facebook, LinkedIn, and YouTube Shorts.

## Quick Start
```bash
npm install
npm run build:csv
# After Drive links are ready:
npm run links
```
