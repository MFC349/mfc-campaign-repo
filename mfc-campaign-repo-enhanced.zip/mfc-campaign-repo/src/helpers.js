export const pad2 = (n)=> (n<10?`0${n}`:`${n}`);
