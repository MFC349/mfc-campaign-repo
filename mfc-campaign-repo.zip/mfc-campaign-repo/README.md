# Molded Fortitude — 6‑Month Campaign Repo

**Purpose:** One repo to generate, track, and export your 6‑month short‑form video campaign for:
- TikTok, Instagram Reels, Facebook, LinkedIn, YouTube Shorts
- Includes Metricool CSV generator, media naming, link injector, and FFmpeg helpers.

## Structure
```
assets/
  logos/           # Place MFC + Beast of Mur logos here (PNG/SVG)
  source_videos/   # Raw clips (MP4) — copy your uploaded files here
  stills/          # Photos for Ken Burns pans
  fonts/
data/
  captions.json    # 24-week captions per platform
  schedule.json    # Calendar + platform cadence
  links.json       # Map placeholders -> Google Drive links (after exporting MP4s)
  metricool.csv    # Generated CSV (placeholders)
  metricool_linked.csv # CSV with live links (after injector)
scripts/
  generate_metricool_csv.js
  inject_links.js
  burn_subtitles.sh
  overlay_text.sh
src/
  helpers.js
.github/workflows/
  build-metricool.yml
.replit
replit.nix
package.json
README.md
LICENSE
```

## Quick Start (Replit or Local)
1. **Upload media** into `assets/source_videos/` and logos into `assets/logos/`.
2. Verify or edit `data/captions.json` and `data/schedule.json`.
3. Generate CSV:
   ```bash
   npm install
   npm run build:csv
   ```
4. After exporting MP4s and uploading to Drive, add links to `data/links.json` and run:
   ```bash
   npm run links
   ```

## Media Placeholders
```
{{WK##_TT}}  TikTok
{{WK##_IG}}  Instagram
{{WK##_FB}}  Facebook
{{WK##_LI}}  LinkedIn
{{WK##_YT}}  YouTube Shorts
```

## Five Story Arcs (cycled)
1. **The Lie I Believed**
2. **The Breaking Point**
3. **The Turning Fire**
4. **The Sacred Rebuild**
5. **The Warrior’s Mission**

## FFmpeg Helpers (optional, zero-cost)
- `scripts/burn_subtitles.sh` — burn an `.srt` into a 9:16 MP4
- `scripts/overlay_text.sh` — overlay hook text with `drawtext`

> CapCut (`.ccproject`) files can live in this repo for versioning; render in CapCut as agreed.

## License
MIT