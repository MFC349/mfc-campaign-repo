#!/usr/bin/env bash
# Usage: scripts/burn_subtitles.sh input.mp4 subs.srt output.mp4
in="$1"; srt="$2"; out="$3"
ffmpeg -y -i "$in" -vf "subtitles='${srt}':force_style='Fontsize=22,PrimaryColour=&HFFFFFF&'" -c:a copy "$out"