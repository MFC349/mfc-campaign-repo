import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { fmtDate } from '../src/helpers.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const captionsPath = path.join(__dirname, '..', 'data', 'captions.json');
const schedulePath = path.join(__dirname, '..', 'data', 'schedule.json');
const outPath = path.join(__dirname, '..', 'data', 'metricool.csv');

const caps = JSON.parse(fs.readFileSync(captionsPath, 'utf-8'));
const sched = JSON.parse(fs.readFileSync(schedulePath, 'utf-8'));

const start = new Date(sched.start_date + "T00:00:00");

function dayIndex(name){
  const map = {SUNDAY:0, MONDAY:1, TUESDAY:2, WEDNESDAY:3, THURSDAY:4, FRIDAY:5, SATURDAY:6};
  return map[name.toUpperCase()];
}

// get date of weekday for week offset from start
function dateForWeekday(start, weekday, weekOffset){
  const base = new Date(start.getTime());
  // Move to Sunday of that week
  const deltaToSun = -base.getDay();
  const sunday = new Date(base.getTime()); sunday.setDate(base.getDate()+deltaToSun + weekOffset*7);
  const d = new Date(sunday.getTime()); d.setDate(sunday.getDate()+weekday);
  return d;
}

const platforms = [
  {key:'tiktok',    network:'TikTok',    post_type:'video', ph:'TT', dow:sched.days_of_week.tiktok,    time:sched.times.tiktok},
  {key:'instagram', network:'Instagram', post_type:'video', ph:'IG', dow:sched.days_of_week.instagram, time:sched.times.instagram},
  {key:'facebook',  network:'Facebook',  post_type:'video', ph:'FB', dow:sched.days_of_week.facebook,  time:sched.times.facebook},
  {key:'linkedin',  network:'LinkedIn',  post_type:'video', ph:'LI', dow:sched.days_of_week.linkedin,  time:sched.times.linkedin},
  {key:'youtube',   network:'YouTube',   post_type:'video', ph:'YT', dow:sched.days_of_week.youtube,   time:sched.times.youtube},
];

let lines = ['network,post_type,date,time,content_url,caption'];

for(let w=0; w<sched.weeks; w++){
  const cap = caps.weeks[w % caps.weeks.length];
  for(const pf of platforms){
    const date = dateForWeekday(start, dayIndex(pf.dow), w);
    const wk = String(w+1).padStart(2,'0');
    const url = `{{WK${wk}_${pf.ph}}}`;
    const caption = cap[pf.key].replace(/\n/g,' ').replace(/"/g,'\"');
    const row = `${pf.network},${pf.post_type},${fmtDate(date)},${pf.time},${url},"${caption}"`;
    lines.push(row);
  }
}

fs.writeFileSync(outPath, lines.join('\n'), 'utf-8');
console.log('Wrote', outPath);