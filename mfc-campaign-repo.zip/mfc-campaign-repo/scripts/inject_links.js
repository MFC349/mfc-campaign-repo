import fs from 'fs';

// Usage: node scripts/inject_links.js data/metricool.csv data/links.json > data/metricool_linked.csv

const [,, csvPath, linksPath] = process.argv;
if(!csvPath || !linksPath){
  console.error('Usage: node scripts/inject_links.js <csvPath> <links.json>');
  process.exit(1);
}

const csv = fs.readFileSync(csvPath, 'utf-8').split('\n');
const links = JSON.parse(fs.readFileSync(linksPath, 'utf-8'));

const out = csv.map((line, idx) => {
  if(idx === 0 || !line.trim()) return line;
  const parts = [];
  let inQuotes = false; let current = '';
  for (let i=0;i<line.length;i++){
    const ch = line[i];
    if(ch === '"') { inQuotes = !inQuotes; current += ch; continue; }
    if(ch === ',' && !inQuotes){ parts.push(current); current=''; continue; }
    current += ch;
  }
  parts.push(current);
  // columns: network,post_type,date,time,content_url,caption
  const url = parts[4];
  const key = url.replace(/[{}]/g,''); // e.g., WK01_TT
  if(links[key]) parts[4] = links[key];
  return parts.join(',');
}).join('\n');

process.stdout.write(out);