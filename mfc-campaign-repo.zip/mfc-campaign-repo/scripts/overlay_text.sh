#!/usr/bin/env bash
# Usage: scripts/overlay_text.sh input.mp4 "Your text here" output.mp4
in="$1"; txt="$2"; out="$3"
ffmpeg -y -i "$in" -vf "drawbox=x=0:y=H*0.8:w=W:h=H*0.2:color=black@0.4:t=fill, drawtext=text='${txt}':fontcolor=white:fontsize=36:x=(w-text_w)/2:y=h*0.83:box=0" -c:a copy "$out"